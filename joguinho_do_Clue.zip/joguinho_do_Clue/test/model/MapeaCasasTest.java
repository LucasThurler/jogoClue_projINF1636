package model;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;

public class MapeaCasasTest {

    @Test
    public void testMapearCasasSumOfDados() {
        Map<Integer, List<Integer>> adj = new HashMap<>();
        adj.put(1, Arrays.asList(2, 3));
        adj.put(2, Arrays.asList(1, 4));
        adj.put(3, Arrays.asList(1));
        adj.put(4, Arrays.asList(2));

        MapeaCasas m = new MapeaCasas(adj);
        int[] dados = {2};
        Set<Integer> res = m.mapearCasas(dados, 1);

        assertTrue(res.contains(2));
        assertTrue(res.contains(3));
        assertTrue(res.contains(4));
        assertEquals(3, res.size());
    }
}
