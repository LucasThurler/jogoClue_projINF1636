package model;

import java.util.*;

public class MapeaCasas {
    private final Map<Integer, List<Integer>> adj;

    public MapeaCasas(Map<Integer, List<Integer>> adj) {
        this.adj = new HashMap<>();
        for (Map.Entry<Integer, List<Integer>> e : adj.entrySet()) {
            this.adj.put(e.getKey(), new ArrayList<>(e.getValue()));
        }
    }

    public Set<Integer> mapearCasas(int[] dados, int casaInicial) {
        int steps = 0;
        for (int d : dados) steps += d;

        Set<Integer> reachable = new HashSet<>();
        Queue<Node> q = new ArrayDeque<>();
        q.add(new Node(casaInicial, 0));
        Set<String> visited = new HashSet<>();
        visited.add(casaInicial + ":" + 0);

        while (!q.isEmpty()) {
            Node n = q.poll();
            if (n.steps > 0) reachable.add(n.pos);
            if (n.steps == steps) continue;
            List<Integer> neighbors = adj.getOrDefault(n.pos, Collections.emptyList());
            for (int nb : neighbors) {
                int ns = n.steps + 1;
                String key = nb + ":" + ns;
                if (ns <= steps && !visited.contains(key)) {
                    visited.add(key);
                    q.add(new Node(nb, ns));
                }
            }
        }

        return reachable;
    }

    private static class Node {
        int pos;
        int steps;
        Node(int p, int s) { pos = p; steps = s; }
    }

    // Main de debug para rodar rapidamente dentro do VS Code
    public static void main(String[] args) {
        Map<Integer, List<Integer>> adj = new HashMap<>();
        adj.put(1, Arrays.asList(2, 3));
        adj.put(2, Arrays.asList(1, 4));
        adj.put(3, Arrays.asList(1));
        adj.put(4, Arrays.asList(2));

        MapeaCasas m = new MapeaCasas(adj);
        int[] dados = {2};
        Set<Integer> reach = m.mapearCasas(dados, 1);
        System.out.println("Dados: " + Arrays.toString(dados) + " -> alcançáveis a partir de 1: " + reach);
    }
}
